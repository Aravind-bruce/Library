import fitz
import requests
import json

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
MODEL_NAME = "mistral:7b-instruct"


def extract_pdf_text(pdf_path):
    try:
        doc = fitz.open(pdf_path)
        full_text = ""

        for page in doc:
            full_text += page.get_text()

        doc.close()

        cleaned_text = full_text.strip()

        if not cleaned_text:
            return None

        return cleaned_text[:12000]

    except Exception as e:
        print("PDF Extraction Error:", e)
        return None


def fallback_extract_from_text(raw_text):
    """
    Fallback if model does not return JSON.
    Uses keyword intelligence from returned explanation.
    """
    try:
        text = raw_text.lower()

        sdg_mapping = {
            1: ["poverty", "income", "employment"],
            2: ["food", "agriculture", "farming"],
            3: ["health", "medical", "brain", "tumor", "mri", "hospital", "clinical", "disease"],
            4: ["education", "student", "learning", "library", "academic"],
            5: ["women", "gender"],
            6: ["water", "sanitation"],
            7: ["energy", "power"],
            8: ["economy", "jobs", "industry"],
            9: ["technology", "innovation", "ai", "deep learning", "cnn", "framework", "system"],
            10: ["inequality"],
            11: ["smart city", "urban", "infrastructure"],
            12: ["consumption", "production"],
            13: ["climate", "environment"],
            14: ["marine", "ocean"],
            15: ["forest", "land", "biodiversity"],
            16: ["justice", "security"],
            17: ["partnership", "global"]
        }

        detected_sdgs = []

        for sdg, keywords in sdg_mapping.items():
            for keyword in keywords:
                if keyword in text:
                    detected_sdgs.append(sdg)
                    break

        detected_sdgs = sorted(list(set(detected_sdgs)))

        # TRL estimation logic
        if any(word in text for word in [
            "prototype", "implemented", "framework developed",
            "tested", "evaluation", "performance"
        ]):
            trl_level = 4

        elif any(word in text for word in [
            "deployed", "clinical integration", "production",
            "commercial", "real-time"
        ]):
            trl_level = 7

        else:
            trl_level = 2

        summary = raw_text[:700].strip()

        if not detected_sdgs:
            return None

        return {
            "sdg_goals": detected_sdgs,
            "trl_level": trl_level,
            "summary": summary
        }

    except Exception as e:
        print("Fallback Extraction Error:", e)
        return None


def clean_json_response(raw_text):
    try:
        start = raw_text.find("{")
        end = raw_text.rfind("}") + 1

        if start != -1 and end != 0:
            json_text = raw_text[start:end]

            print("CLEANED JSON RESPONSE:")
            print(json_text)

            return json.loads(json_text)

        print("No valid JSON found. Using fallback analysis.")

        return fallback_extract_from_text(raw_text)

    except Exception as e:
        print("JSON Cleaning Error:", e)
        print("RAW MODEL RESPONSE:", raw_text)
        print("Attempting fallback extraction...")

        return fallback_extract_from_text(raw_text)


def validate_analysis(parsed):
    try:
        if not parsed:
            return None

        sdg_goals = parsed.get("sdg_goals")
        trl_level = parsed.get("trl_level")
        summary = parsed.get("summary")

        if not isinstance(sdg_goals, list):
            print("Invalid SDG format.")
            return None

        validated_sdgs = []

        for goal in sdg_goals:
            try:
                goal_num = int(goal)
                if 1 <= goal_num <= 17:
                    validated_sdgs.append(goal_num)
            except:
                continue

        validated_sdgs = sorted(list(set(validated_sdgs)))

        if not validated_sdgs:
            print("No valid SDGs found.")
            return None

        try:
            trl_level = int(trl_level)

            if not (1 <= trl_level <= 9):
                print("TRL out of valid range.")
                return None

        except:
            print("Invalid TRL value.")
            return None

        if not summary or not isinstance(summary, str):
            print("Invalid summary.")
            return None

        return {
            "sdg_goals": validated_sdgs,
            "trl_level": trl_level,
            "summary": summary.strip()
        }

    except Exception as e:
        print("Validation Error:", e)
        return None


def analyze_project(pdf_path, title, abstract, keywords):
    pdf_text = extract_pdf_text(pdf_path)

    if not pdf_text:
        print("No valid PDF text extracted.")
        return None

    prompt = f"""
You are an expert academic innovation evaluator.

Analyze the uploaded project information and PDF content.

Return ONLY valid JSON:

{{
  "sdg_goals": [1,2],
  "trl_level": 1,
  "summary": "Short professional summary"
}}

STRICT RULES:
- JSON ONLY
- NO markdown
- NO explanation
- NO paragraphs
- NO notes
- SDGs must be integers 1-17
- TRL must be integer 1-9
- Summary must be concise

Project Title:
{title}

Abstract:
{abstract}

Keywords:
{keywords}

PDF Content:
{pdf_text}
"""

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0,
                    "top_p": 0.1,
                    "repeat_penalty": 1.3,
                    "num_predict": 400
                }
            },
            timeout=180
        )

        response.raise_for_status()

        raw_result = response.json().get("response", "").strip()

        print("RAW MODEL OUTPUT:")
        print(raw_result)

        parsed = clean_json_response(raw_result)

        if not parsed:
            print("Parsing failed.")
            return None

        validated_result = validate_analysis(parsed)

        if not validated_result:
            print("Validation failed.")
            return None

        print("FINAL VALIDATED RESULT:")
        print(validated_result)

        return validated_result

    except requests.exceptions.RequestException as e:
        print("Ollama Connection Error:", e)
        return None

    except Exception as e:
        print("AI Analysis Error:", e)
        return None