from django.apps import AppConfig


class ProjectDeatilsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project_deatils'
